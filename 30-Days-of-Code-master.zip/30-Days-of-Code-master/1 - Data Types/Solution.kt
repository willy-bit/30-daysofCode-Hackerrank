fun main(args: Array<String>) {
    val i = 4
    val d = 4.0
    val s = "HackerRank "

    val i2 = readLine()!!.toInt()
    val d2 = readLine()!!.toDouble()
    val s2 = readLine()!!.toString()

    println(i + i2)
    println(d + d2)
    println(s + s2)
}
