i = 4
d = 4.0
s = 'HackerRank '
# Declare second integer, double, and String variables.
i_in = readline.to_i
d_in = readline.to_f
s_in = readline

# Print the sum of both integer variables on a new line.
puts i+i_in

# Print the sum of the double variables on a new line.
puts d+d_in

# Concatenate and print the String variables on a new line
# The 's' variable above should be printed first.
puts s+s_in
