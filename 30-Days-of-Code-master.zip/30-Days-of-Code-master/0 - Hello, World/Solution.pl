my $inputString = <STDIN>; # get a line of input from stdin and save it to our variable

# Your first line of output goes here
print "Hello, World.\n";

# Write the second line of output
print $inputString;
