# print "Hello World" => shift to new line => print stdin
printf "Hello, World.\n$(</dev/stdin)"
