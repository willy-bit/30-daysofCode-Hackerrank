using System;

class Solution
{
    static void Main(String[] args)
    {
        // Declare a variable named 'inputString' to hold our input.
        String inputString;

        // Read a full line of input from stdin and save it to our variable, inputString.
        inputString = Console.ReadLine();

        // Print a string literal saying "Hello, World." to the stdout.
        Console.WriteLine("Hello, World.");

        // Prints the contents of inputString to stdout.
        Console.WriteLine(inputString);
    }
}
