// Read a full line of input from stdin and save it to our variable, inputString.
let inputString = readLine()!

// Print a string literal saying "Hello, World." to the stdout.
print("Hello, World.")

// Prints the contents of inputString to stdout.
print(inputString)
