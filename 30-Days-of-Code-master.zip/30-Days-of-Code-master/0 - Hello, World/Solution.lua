a = io.read()
print("Hello, World.")
print(a) 
