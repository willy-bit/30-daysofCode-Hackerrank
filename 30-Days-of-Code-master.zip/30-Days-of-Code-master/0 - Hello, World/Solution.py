# print "Hello World" => jump to new line => print input string
print("Hello, World. \n" + input())
