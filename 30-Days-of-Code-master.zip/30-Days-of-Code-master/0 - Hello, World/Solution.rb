# Read a full line of input from stdin and save it to our dynamically typed variable, input_string.
input_string = gets

# Print a string literal saying "Hello, World." to stdout.
puts 'Hello, World.'

# TODO: Write a line of code here that prints the contents of input_string to stdout.
puts input_string
