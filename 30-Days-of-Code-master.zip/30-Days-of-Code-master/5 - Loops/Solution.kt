fun main(args: Array<String>) {
    val N = readLine()!!.toInt()
    for (i in 1..10) println("$n x $i = ${n * i}")
}
