typeof "John"                 
typeof 3.14                   
typeof NaN                    
typeof false                  
typeof [1, 2, 3, 4]           
typeof {name:'John', age:34}  
typeof new Date()             
typeof function () {}         
typeof myCar                  
typeof null                   
