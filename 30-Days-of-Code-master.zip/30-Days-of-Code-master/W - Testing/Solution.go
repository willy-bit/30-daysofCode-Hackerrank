package main

import "fmt"

func main() {
	fmt.Println("5")
	fmt.Println("4 3")
	fmt.Println("-1 0 4 2")
	fmt.Println("5 2")
	fmt.Println("0 -1 2 1 4")
	fmt.Println("7 6")
	fmt.Println("2 0 -1 1 1 1 1")
	fmt.Println("3 1")
	fmt.Println("-1 0 4")
	fmt.Println("6 4")
	fmt.Println("0 -1 1 4 5 6")
}
