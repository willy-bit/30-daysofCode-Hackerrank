using System;

class Solution
{
    static void Main(String[] args)
    {
        Console.WriteLine(5);
        Console.WriteLine("4 3");
        Console.WriteLine("0 -3 4 2");
        Console.WriteLine("5 2");
        Console.WriteLine("0 -3 4 2 2");
        Console.WriteLine("3 3");
        Console.WriteLine("0 -3 4");
        Console.WriteLine("7 2");
        Console.WriteLine("0 -3 1 1 1 1 1");
        Console.WriteLine("6 3");
        Console.WriteLine("0 -3 4 2 1 1");
    }
}
